/** Process-local UI observations; ended means driver idle, not task acceptance. */
import { STAGES, type Stage, type StageStatus, type TaskProgress } from '../shared';
export function createProgress(full = true): TaskProgress {
  const now = new Date().toISOString();
  return { current: full ? 'triage' : 'execute', updatedAt: now, steps: STAGES.map(id => ({ id, status: id === 'input' ? 'done' : id === (full ? 'triage' : 'execute') ? 'active' : !full && ['triage', 'compare', 'verify', 'assemble'].includes(id) ? 'skipped' : 'pending', ...(id === 'input' ? { startedAt: now, finishedAt: now } : id === (full ? 'triage' : 'execute') ? { startedAt: now } : {}) })) };
}
/** Set only observed stages; unsubmitted judgments stay pending until supplied. */
export function mark(progress: TaskProgress, id: Stage, status: StageStatus, note?: string): void {
  const step = progress.steps.find(step => step.id === id)!;
  const now = new Date().toISOString();
  if (status === 'active') {
    for (const previous of progress.steps) if (previous.id !== id && previous.status === 'active') {
      // A stage left without a submission is unknown, never silently completed.
      previous.status = previous.id === 'execute' ? 'ended' : 'pending';
      if (previous.status === 'ended') previous.finishedAt = now;
    }
  }
  step.status = status;
  if (note !== undefined) step.note = note;
  else if (!['failed', 'degraded', 'paused'].includes(status)) delete step.note;
  if (status === 'pending') { delete step.startedAt; delete step.finishedAt; }
  if (status !== 'pending') step.startedAt ??= now;
  if (status === 'done' || status === 'ended') step.finishedAt = now;
  else delete step.finishedAt;
  if (status !== 'done' && status !== 'pending') progress.current = id;
  progress.updatedAt = now;
}
