/** Incremental task data; never rewrites the initial prompt or foreign configuration. */
import { STAGES, phaseOf, deliveryBundle, type Stage, type Todo } from '../shared';
import { mark } from './progress';
import type { State } from './index';
import type { Agent, Execution, ToolDescriptor } from './types';

const now = () => new Date().toISOString();
export const normalize = (value: string) => value.normalize('NFKC').replace(/\s+/gu, ' ').trim();
export function report(state: State, stage: Stage, summary: string, source: string): void {
  const previous = state.reports.at(-1);
  if (previous?.stage === stage && previous.summary === summary && previous.source === source) return;
  state.reports.push({ stage, summary, source, recordedAt: now() });
}
export function savePlan(state: State, plan: string, reason: string, requirementIds: string[] = ['initial']): void {
  if (state.planVersions.at(-1)?.plan !== plan) state.planVersions.push({ version: state.planVersions.length + 1, plan, reason, requirementIds, recordedAt: now() });
  state.conclusion = plan;
  report(state, 'assemble', plan, reason);
}
export function invalidateDelivery(state: State): void {
  state.acceptance = ''; state.delivery = undefined;
  for (const id of ['trace', 'accept', 'construction'] as const) mark(state.progress, id, 'pending');
}
function arg(args: Record<string, unknown>, name: string): string {
  const value = args[name];
  if (typeof value !== 'string' || !value.trim() || value.length > 100000) throw new Error(`Invalid ${name}`);
  return value;
}
function refs(state: State, value: unknown): string[] {
  if (!Array.isArray(value) || !value.length || value.some(id => typeof id !== 'string' || id !== 'initial' && !state.supplements.some(r => r.id === id))) throw new Error('requirementIds must reference initial or captured supplement IDs');
  return [...new Set(value)] as string[];
}
function upsert(state: State, args: Record<string, unknown>, requirementIds: string[]): Todo {
  const text = arg(args, 'text'), reason = arg(args, 'reason');
  const requestedId = args.id;
  if (requestedId !== undefined && typeof requestedId !== 'string') throw new Error('Invalid todo id');
  const existing = requestedId ? state.todos.find(t => t.id === requestedId) : state.todos.find(t => normalize(t.text) === normalize(text));
  if (requestedId && !existing) throw new Error('Unknown todo id');
  const status = args.status ?? existing?.status ?? 'pending';
  if (!['pending', 'active', 'done', 'cancelled'].includes(String(status))) throw new Error('Invalid todo status');
  if (args.evidence !== undefined && typeof args.evidence !== 'string') throw new Error('Invalid evidence');
  const next: Todo = { id: existing?.id ?? `t${state.todos.length + 1}`, text, reason, status: status as Todo['status'], requirementIds: [...new Set([...(existing?.requirementIds ?? []), ...requirementIds])], evidence: args.evidence as string | undefined ?? existing?.evidence, updatedAt: existing?.updatedAt ?? now() };
  if (existing && JSON.stringify(existing) === JSON.stringify(next)) return existing;
  next.updatedAt = now();
  state.todoChanges.push({ todoId: next.id, before: existing ? structuredClone(existing) : undefined, after: structuredClone(next), recordedAt: now() });
  if (existing) state.todos[state.todos.indexOf(existing)] = next; else state.todos.push(next);
  for (const id of requirementIds) { const r = state.supplements.find(r => r.id === id); if (r && !r.todoIds.includes(next.id)) r.todoIds.push(next.id); }
  state.revision++; invalidateDelivery(state);
  return next;
}
const schema = (properties: object, required: string[]) => ({ type: 'object', properties, required, additionalProperties: false });
const text = { type: 'string' };
export function workflowTools(requireState: (exec: Execution) => { state: State; agent: Agent }, output: ToolDescriptor['output']): ToolDescriptor[] {
  return [
    { name: 'dispatch_report', description: 'Record a user-visible understanding for any step and optionally the evidence-based static/dynamic identity, scale and reason for this phase. Reports are advisory, never switch host roles. Also explain this understanding to the user.',
      parameters: schema({ stage: { type: 'string', enum: [...STAGES] }, understanding: text, source: text, identity: text, identityMode: { type: 'string', enum: ['static', 'dynamic'] }, scale: text, evidence: text, reason: text }, ['stage', 'understanding', 'source']), output,
      async execute(value, exec) {
        const { state } = requireState(exec); exec.signal.throwIfAborted(); const args = value as Record<string, unknown>;
        const stage = arg(args, 'stage') as Stage;
        if (!STAGES.includes(stage)) throw new Error('Unknown stage');
        const understanding = arg(args, 'understanding'), source = arg(args, 'source');
        const identity = args.identity !== undefined ? { identity: arg(args, 'identity'), mode: arg(args, 'identityMode'), scale: arg(args, 'scale'), evidence: arg(args, 'evidence'), reason: arg(args, 'reason') } : undefined;
        if (identity && identity.mode !== 'static' && identity.mode !== 'dynamic') throw new Error('Invalid identityMode');
        report(state, stage, understanding, source);
        if (identity) state.identities.push({ ...identity, mode: identity.mode as 'static' | 'dynamic', stage, phase: phaseOf(stage), recordedAt: now() });
        state.progress.updatedAt = now();
        return { status: 'recorded', understanding, identity, advisory: true };
      } },
    { name: 'dispatch_todo', description: 'Add or update a todo with source requirement IDs (initial or captured r IDs), reason, status and actual completion evidence. Repeated identical submissions do not duplicate todos or history. No mandatory planning prerequisites.',
      parameters: schema({ id: text, text, reason: text, status: { type: 'string', enum: ['pending', 'active', 'done', 'cancelled'] }, requirementIds: { type: 'array', items: text, minItems: 1 }, evidence: text }, ['text', 'reason', 'requirementIds']), output,
      async execute(value, exec) {
        const { state } = requireState(exec); exec.signal.throwIfAborted(); const args = value as Record<string, unknown>;
        const revision = state.revision;
        const todo = upsert(state, args, refs(state, args.requirementIds));
        if (state.revision === revision) return { status: 'unchanged', todo };
        report(state, 'todo', `${todo.text}\n${todo.reason}`, 'dispatch_todo'); mark(state.progress, 'todo', 'done'); mark(state.progress, 'execute', 'active');
        return { status: 'recorded', todo, openTodos: state.todos.filter(t => !['done', 'cancelled'].includes(t.status)).length };
      } },
    { name: 'dispatch_adjust', description: 'Assess one captured supplementary prompt without rerunning planning. Report understanding and impact; optionally add/update a todo and plan version. Duplicate/no-impact assessments only link existing work, without changing todos or the plan. Use actual r IDs from the task context.',
      parameters: schema({ requirementId: text, kind: { type: 'string', enum: ['add', 'change', 'duplicate', 'clarification', 'no-impact'] }, understanding: text, impact: text, todoId: text, todo: text, planUpdate: text }, ['requirementId', 'kind', 'understanding', 'impact']), output,
      async execute(value, exec) {
        const { state } = requireState(exec); exec.signal.throwIfAborted(); const args = value as Record<string, unknown>;
        const r = state.supplements.find(r => r.id === arg(args, 'requirementId'));
        if (!r) throw new Error('Unknown requirementId');
        const kind = arg(args, 'kind') as NonNullable<typeof r.kind>, understanding = arg(args, 'understanding'), impact = arg(args, 'impact');
        if (!['add', 'change', 'duplicate', 'clarification', 'no-impact'].includes(kind)) throw new Error('Invalid adjustment kind');
        if (['duplicate', 'no-impact'].includes(kind) && (args.todo !== undefined || args.planUpdate !== undefined)) throw new Error('Duplicate/no-impact assessments cannot mutate todos or plans');
        const existing = args.todoId !== undefined ? state.todos.find(t => t.id === arg(args, 'todoId')) : undefined;
        if (args.todoId !== undefined && !existing) throw new Error('Unknown todoId');
        const todoText = args.todo !== undefined ? arg(args, 'todo') : undefined;
        const planUpdate = args.planUpdate !== undefined ? arg(args, 'planUpdate') : undefined;
        // Idempotent model retries produce no extra plan/todo revisions.
        if (r.status === 'assessed' && r.kind === kind && r.understanding === understanding && r.impact === impact && (!existing || r.todoIds.includes(existing.id)) && (!todoText || r.todoIds.some(id => state.todos.find(t => t.id === id)?.text === todoText)) && (!planUpdate || state.conclusion === planUpdate)) return { status: 'unchanged', requirement: r };
        if (todoText) {
          const todo = upsert(state, { id: existing?.id, text: todoText, reason: impact, ...(kind === 'change' ? { status: 'pending', evidence: '' } : {}) }, [r.id]);
          if (!r.todoIds.includes(todo.id)) r.todoIds.push(todo.id);
        } else if (existing && !r.todoIds.includes(existing.id)) r.todoIds.push(existing.id);
        if (planUpdate) savePlan(state, planUpdate, impact, [r.id]);
        Object.assign(r, { kind, understanding, impact, status: 'assessed' });
        for (const duplicate of state.supplements.filter(item => item.duplicateOf === r.id)) duplicate.todoIds = [...r.todoIds];
        state.revision++; invalidateDelivery(state); report(state, 'supplement', `${understanding}\n${impact}`, r.id);
        mark(state.progress, 'supplement', state.supplements.some(r => r.status === 'pending') ? 'active' : 'done');
        if (!state.supplements.some(r => r.status === 'pending')) mark(state.progress, 'execute', 'active');
        return { status: 'assessed', requirement: r, planVersion: state.planVersions.at(-1), todos: state.todos, planningPreserved: true };
      } },
    { name: 'dispatch_delivery', description: 'Record actual delivery summary, the initial-plus-supplement requirement-to-result/evidence comparison, and separate construction requests (say none if absent). Export retains every original prompt, plan and todo change. Missing assessments/evidence remain visible gaps, never a forced acceptance gate.',
      parameters: schema({ summary: text, requirements: text, constructionRequests: text }, ['summary', 'requirements', 'constructionRequests']), output,
      async execute(value, exec) {
        const { state } = requireState(exec); exec.signal.throwIfAborted(); const args = value as Record<string, unknown>;
        state.delivery = { summary: arg(args, 'summary'), requirements: arg(args, 'requirements'), constructionRequests: arg(args, 'constructionRequests'), revision: state.revision, recordedAt: now() };
        report(state, 'trace', state.delivery.requirements, 'dispatch_delivery'); report(state, 'construction', state.delivery.constructionRequests, 'dispatch_delivery');
        mark(state.progress, 'trace', 'done'); mark(state.progress, 'construction', 'done'); mark(state.progress, 'accept', state.acceptance ? 'done' : 'pending');
        state.progress.current = 'trace';
        return { status: 'recorded', report: deliveryBundle(state), instruction: 'Explain actual requirement coverage and gaps; independent judge evaluation is optional and remains distinct.' };
      } },
    { name: 'dispatch_export', description: 'Return the complete delivery report including unchanged initial prompt, every supplementary prompt, plan versions, todo history, identities, evidence and gaps. Read-only; not a claim that acceptance passed.', parameters: schema({}, []), output,
      async execute(_value, exec) { const { state } = requireState(exec); exec.signal.throwIfAborted(); return deliveryBundle(state); } },
  ];
}
