/** Three visible phases with expandable evidence and model understanding. */
import React, { useEffect, useState } from 'react';
import { PHASES, PHASE_STAGES, phaseOf, deliveryBundle, type Stage, type TaskPhase, type TaskRecord } from '../shared';
export type StageTask = Omit<TaskRecord, 'catalog'>;
type Translate = (key: string) => string;
function pretty(value: string): string {
  try { const parsed: unknown = JSON.parse(value); return typeof parsed === 'object' && parsed !== null ? JSON.stringify(parsed, null, 2) : value; } catch { return value; }
}
function evidence(task: StageTask, id: Stage): string {
  switch (id) {
    case 'input': return task.prompt;
    case 'triage': return task.triage;
    case 'compare': return task.comparison;
    case 'verify': return task.review;
    case 'assemble': return task.conclusion;
    case 'trace': return task.delivery?.requirements ?? '';
    case 'construction': return task.delivery?.constructionRequests ?? '';
    case 'accept': return task.acceptance ?? '';
    default: return '';
  }
}
export function TaskStages({ task, t }: { task: StageTask; t: Translate }) {
  const [expanded, setExpanded] = useState<Partial<Record<Stage, boolean>>>({});
  const currentPhase = phaseOf(task.progress.current);
  const [phaseExpanded, setPhaseExpanded] = useState<Partial<Record<TaskPhase, boolean>>>({ [currentPhase]: true });
  useEffect(() => { setPhaseExpanded(previous => ({ ...previous, [currentPhase]: true })); }, [currentPhase]);
  const download = () => {
    const blob = new Blob([JSON.stringify(deliveryBundle(task), null, 2)], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob), link = document.createElement('a');
    link.href = url; link.download = 'orchestrator-suite-3.0-delivery.json'; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  return <><p className="os-caption">{t('workflow.advisory')} · {t(`workflow.${task.guidance ?? 'light'}`)}{task.triggerReason && <><br />{task.triggerReason}</>}</p>
    <ol className="os-stage-list" aria-label={t('progress.stages')}>{PHASES.map((phase, index) => <li key={phase}><details className={currentPhase === phase ? 'os-phase os-phase-current' : 'os-phase'} data-phase={phase} open={!!phaseExpanded[phase]} onToggle={event => { const open = event.currentTarget.open; setPhaseExpanded(previous => previous[phase] === open ? previous : { ...previous, [phase]: open }); }}>
      <summary className="os-phase-header"><span>{index + 1}/3</span><strong>{t(`workflow.phase.${phase}`)}</strong><small>{t(`workflow.phase.${phase}.description`)}</small></summary>
      <div className="os-phase-identity"><strong>{t('workflow.identity')}</strong>{task.identities?.filter(r => r.phase === phase).length ? <details><summary>{task.identities.filter(r => r.phase === phase).at(-1)!.identity} · {t(`workflow.identity.${task.identities.filter(r => r.phase === phase).at(-1)!.mode}`)}</summary>{task.identities.filter(r => r.phase === phase).map((r, i) => <div key={i}><p>{t(`stage.${r.stage}`)} · {r.identity} · {r.scale}</p><pre>{r.reason}{'\n'}{r.evidence}</pre></div>)}</details> : <span>{t('workflow.identityPending')}</span>}</div>
      <ol className="os-phase-steps">{PHASE_STAGES[phase].map(id => {
        const step = task.progress.steps.find(step => step.id === id);
        if (!step) return null;
        const value = evidence(task, id), understanding = task.reports?.filter(r => r.stage === id).at(-1);
        const issue = step.note || ((step.status === 'degraded' || step.status === 'failed') && task.progress.steps.filter(s => ['degraded', 'failed'].includes(s.status)).length === 1 ? task.progress.error : undefined);
        return <li key={id}><details className={`os-stage-row os-stage-${step.status}`} data-stage={id} open={!!expanded[id]} onToggle={event => {
          const open = event.currentTarget.open;
          setExpanded(previous => previous[id] === open ? previous : { ...previous, [id]: open });
        }} aria-current={id === task.progress.current ? 'step' : undefined}>
          <summary><span className="os-stage-chevron" aria-hidden="true">›</span><span className={`os-status-light os-status-${step.status}`} aria-hidden="true" /><strong>{t(`stage.${id}`)}</strong><span className="os-stage-state">{t(`progress.status.${step.status}`)}</span></summary>
          <div className="os-stage-evidence">
            <div className="os-understanding"><strong>{t('workflow.understanding')}</strong>{understanding ? <><pre>{understanding.summary}</pre><small>{understanding.source}</small></> : <p className="os-caption">{t('workflow.understandingPending')}</p>}</div>
            {id === 'supplement' ? <div>{task.supplements?.length ? task.supplements.map(r => <article className="os-requirement" key={r.id}><strong>{r.id} · {t(`workflow.requirement.${r.status}`)}{r.duplicateOf && ` → ${r.duplicateOf}`}</strong><pre>{r.prompt}</pre><p>{r.understanding || t('workflow.understandingPending')}</p><p>{r.impact || t('workflow.impactPending')}</p><small>{r.todoIds.join(' · ') || t('workflow.noTodoChange')}</small></article>) : <p>{t('workflow.noSupplements')}</p>}</div>
              : id === 'todo' ? <>{task.todos?.length ? <ul className="os-todos">{task.todos.map(todo => <li key={todo.id}><strong>{todo.id} · {t(`workflow.todo.${todo.status}`)}</strong><p>{todo.text}</p><small>{todo.requirementIds.join(' · ')} · {todo.reason}</small>{todo.evidence && <pre>{todo.evidence}</pre>}</li>)}</ul> : <p>{t('workflow.noTodos')}</p>}{!!task.todoChanges?.length && <details><summary>{t('workflow.todoHistory')} ({task.todoChanges.length})</summary><pre>{JSON.stringify(task.todoChanges, null, 2)}</pre></details>}</>
              : id === 'execute' ? <p>{step.startedAt ? t('progress.executionObserved') : t('progress.executionPending')}</p>
              : value ? <pre>{id === 'input' ? value : pretty(value)}</pre> : <p className="os-caption">{['degraded', 'failed', 'paused'].includes(step.status) ? t('progress.noResult') : step.status === 'skipped' ? t('progress.notCalled') : t('pending')}</p>}
            {id === 'assemble' && !!task.planVersions?.length && <details><summary>{t('workflow.planHistory')} ({task.planVersions.length})</summary><pre>{JSON.stringify(task.planVersions, null, 2)}</pre></details>}
            {id === 'trace' && <><p>{task.delivery?.summary}</p><details className="os-prompt-export"><summary>{t('workflow.allPrompts')}</summary><strong>{t('task.prompt')}</strong><pre>{task.prompt}</pre>{task.supplements?.map(r => <div key={r.id}><strong>{r.id} · {t('turn')} {r.turn}</strong><pre>{r.prompt}</pre></div>)}</details><button className="os-export" onClick={download}>{t('workflow.export')}</button><ul>{deliveryBundle(task).gaps.map(gap => <li key={gap}>{gap}</li>)}</ul></>}
            {issue && <div className="os-stage-issue"><strong>{t('progress.reason')}</strong><pre>{issue}</pre></div>}
            {(step.startedAt || step.finishedAt) && <dl className="os-stage-times">{step.startedAt && <><dt>{t('progress.started')}</dt><dd><time dateTime={step.startedAt}>{new Date(step.startedAt).toLocaleString()}</time></dd></>}{step.finishedAt && <><dt>{t('progress.finished')}</dt><dd><time dateTime={step.finishedAt}>{new Date(step.finishedAt).toLocaleString()}</time></dd></>}</dl>}
            {id === 'compare' && !!task.observations?.length && <details className="os-stage-observations"><summary>{t('task.observations')}</summary><pre>{JSON.stringify(task.observations, null, 2)}</pre></details>}
            {id === 'verify' && <p className="os-caption">{t('proposalEvidence')}</p>}
            {id === 'accept' && <p className="os-caption">{t('acceptanceEvidence')}</p>}
          </div>
        </details></li>;
      })}</ol>
    </details></li>)}</ol></>;
}
