# 3.0 部署说明

## 发布内容与范围

本套件拥有 `orchestrator-suite` bundle、编排看板、`orchestrator-suite:progress` 标题栏状态和 `dispatch-orchestrator` 调度编排模式。3.0 将七个平铺步骤改为三个阶段内的 11 个步骤。路由与已有工具名称兼容，新增增量需求、待办、理解/身份和交付导出工具；第三方验证器保持独立。

发布包不携带机器绝对路径、账户或会话记录。`suite.config.json` 的资料目录默认空数组；既有安装升级保留本地配置，新增阈值缺省采用 600 字或 4 段且 120 字。也可通过 `ORCHESTRATOR_SUITE_CONFIG` 提供独立配置。

## 验证与打包

1. `node scripts/verify.mjs`：类型、生产构建、依赖解析、自动测试、真实宿主组合或明确跳过、隐私扫描。
2. `node scripts/pack.mjs <输出目录>`：发布清单复制、逐文件 SHA-256、tar.gz、解包复查与入口加载。
3. 保存 tar.gz、同名 `.sha256` 与 `.release.json`，检查 `docs/RELEASE-SUMMARY.json` 的验证边界。

配置组合需要显式的 `ORCHESTRATOR_PROFILE` 和 `ORCHESTRATOR_DSH_CLI`。preflight 将 profile 的配置复制到本套件临时目录，仅将该套件解析到待交付源码，其他依赖继续解析到原有目录，不改实际 profile。读取官方 CLI 的 `--dump-config`，确认新入口与调度编排模式进入组合结果。第三方告警如实记录，不能通过修改其他插件修复它们。未提供真实宿主时记录 `skipped`，不算通过。

## 原位升级

已有本套件安装且 profile 使用 `link:` 时，可运行 `node scripts/deploy-in-place.mjs`。显式设置 `ORCHESTRATOR_INSTALL_DIR` 指向用户批准的既有套件目录。脚本要求当前版本 verification/preflight 通过；校验包名、既有 bundle 和实际软链目标；只覆盖该套件发布清单中的文件。保留本地配置和非发布文件，保存覆盖前备份，profile 四个关键文件和其他插件源码/构建/预设文件升级前后作哈希对照。不删除其他文件，不修改任何其他 bundle、状态栏或预设。

原位备份和 `docs/installation.json` 仅为本机证据，不进入发布包。复制完成不表示活体已应用；不能仅凭磁盘、日志或构建结果宣称生效。需要可用的 DSH 公共插件管理 `application: applied`、公开装配检查以及真实 UI/工具验收。该升级脚本不重启宿主、不调用裁判、不改模型连接或安全配置。

回滚：按 installation 报告中 backup 指向的清单，恢复该套件此次覆盖前的文件；其他插件与 profile 从未被写入。已有进程的缓存加载与下一次加载的入口不同，需依宿主公共流程确认应用。不要手工清空 profile、重装全部插件或用另一个 Loader 源重复加载同一包。

## 验收证据边界

自动测试覆盖三阶段展示、关闭路径、会话隔离、补充保持原始提示词、阈值边界、重复去重、待办修订历史、身份报告、完整原文导出、过期验证结果隔离和降级语义。CLI 组合验证不启动 GUI、不付费调用裁判。真实宿主中的打开/关闭、明暗主题、实际第三方调用及任务跨阶段表现需要另行提供证据；不能用测试数据冒充实际任务结果。

初始与过程提示词在任务报告中完整保留；跨轮次持续管理，进程退出不自动持久恢复。导出文件包含用户输入，应由用户选择保存位置。
