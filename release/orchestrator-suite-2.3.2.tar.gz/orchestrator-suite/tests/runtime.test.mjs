import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createRuntime, mount } from '../lib/host-2.3.2.js';

const config = JSON.parse(await fs.readFile(new URL('../suite.config.json', import.meta.url), 'utf8'));
function setup({ preset = 'dispatch-orchestrator', verifier, skills = [] } = {}) {
  const events = new Map(), routes = [], registered = [], sections = [], contexts = [];
  const agent = { id: 'main-1', ctx: {}, session: { header: {} } };
  const ctx = {
    logger: { warn() {} }, effect: f => f(), inject: (_n, f) => f(ctx), on: (event, f) => events.set(event, f),
    systemPrompt: { section: s => { sections.push(s); return () => {}; } },
    skills: { list: async () => skills },
    pluginManager: { listBundles: async () => [], listPlugins: async () => [] },
    agentPresets: { composedPreset: () => preset, compositionInventory: async () => [] },
    agents: { get: id => id === agent.id ? agent : undefined, list: () => [agent] },
    tools: { schemas: () => [], register: tool => { registered.push(tool); return () => {}; }, get: () => verifier ? {} : undefined, execute: async args => verifier(args) },
    connection: { fetch: { register: r => { routes.push(r); return async () => {}; } } },
  };
  const settings = { ...config, assetRoots: [], memoryRoots: [] };
  const runtime = createRuntime(ctx, settings);
  const exec = { agent, signal: new AbortController().signal, callId: 'call', token: Symbol(), deferContext: c => contexts.push(c) };
  const capture = (prompt = '原始任务\n保留文本', turn = 1) => runtime.capture({ agent, message: { source: { kind: 'user' }, content: [{ type: 'text', text: prompt }] }, turn });
  const call = (name, args = {}, execution = exec) => runtime.tools.find(t => t.name === name).execute(args, execution);
  capture();
  return { ctx, runtime, agent, exec, call, capture, settings, events, routes, sections, registered, contexts };
}
test('ordinary mode can submit triage and layers and observe actual execution', async () => {
  const s = setup({ preset: 'standard' });
  s.runtime.observeStep(s.agent);
  assert.equal(s.runtime.states.get(s.agent).progress.current, 'execute');
  await s.call('dispatch_plan', { triage: 'L1 明确范围' });
  await s.call('relic_prepare');
  await s.call('dispatch_context', { comparison: '工具可用，其他层未知', conclusion: '继续实施' });
  s.runtime.observeStatus({ agent: s.agent, status: 'idle' });
  const state = s.runtime.states.get(s.agent);
  assert.equal(state.progress.steps.find(s => s.id === 'execute').status, 'ended');
  assert.equal(state.progress.steps.find(s => s.id === 'accept').status, 'pending');
});
test('missing judge is degraded and commit continues without fabricated success', async () => {
  const s = setup();
  const result = await s.call('dispatch_review', { triage: 'L1', comparison: '发现失败；使用可用工具' });
  assert.equal(result.status, 'degraded');
  await s.call('dispatch_commit', { conclusion: '裁判不可用；记录自检证据继续' });
  const state = s.runtime.states.get(s.agent);
  assert.equal(state.progress.current, 'execute'); assert.equal(state.review, '');
  assert.equal(state.progress.steps.find(s => s.id === 'verify').status, 'degraded');
});
test('registry failure is advisory and does not stop the task', async () => {
  const s = setup(); s.ctx.skills.list = async () => { throw new Error('skills offline'); };
  const result = await s.call('relic_prepare'); assert.match(result.warnings.join(), /skills offline/);
  await s.call('dispatch_context', { comparison: '技能未知', conclusion: '使用现有能力' });
  assert.equal(s.runtime.states.get(s.agent).progress.current, 'execute');
});
test('real review carries exact original prompt, stage and actual contexts', async () => {
  let request;
  const s = setup({ verifier: args => { request = args; return { isError: false, value: { winner: 'B', scoreA: .2 }, content: [], additionalContexts: ['judge context'] }; } });
  await s.call('dispatch_review', { triage: 'L1', comparison: '明确依赖' });
  assert.equal(JSON.parse(request.arguments.problem).original_user_prompt, '原始任务\n保留文本');
  assert.equal(request.arguments.review_stage, 'proposal'); assert.deepEqual(s.contexts, ['judge context']);
  await s.call('dispatch_commit', { conclusion: '采纳直接执行基线' });
});
test('steering invalidates an in-flight review and old acceptance', async () => {
  let finish;
  const s = setup({ verifier: () => new Promise(resolve => { finish = resolve; }) });
  const pending = s.call('dispatch_review', { triage: 'L1', comparison: '旧任务' });
  s.capture('补充约束', 1); finish({ isError: false, value: {}, content: [] });
  await assert.rejects(pending, /Task changed/);
  assert.equal(s.runtime.states.get(s.agent).review, ''); assert.match(s.runtime.states.get(s.agent).prompt, /补充约束/);
});
test('cancellation remains cancellation and cannot commit a fake review', async () => {
  const controller = new AbortController();
  const s = setup({ verifier: () => { controller.abort(); return { isError: false, value: {}, content: [] }; } });
  await assert.rejects(s.call('dispatch_review', { triage: 'L0', comparison: '参考' }, { ...s.exec, signal: controller.signal }));
  assert.equal(s.runtime.states.get(s.agent).progress.steps.find(s => s.id === 'verify').status, 'paused');
});
test('delivery evaluation is distinct and never asserts threshold success', async () => {
  let request;
  const s = setup({ verifier: args => { request = args; return { isError: false, content: [], value: { score: .1, winner: 'B', criteria: [{ score: .1 }] } }; } });
  const result = await s.call('dispatch_accept');
  assert.equal(request.name, 'verifier_current_session'); assert.equal(result.status, 'evaluated');
  assert.equal(result.acceptance.score, .1); assert.equal('passed' in result, false);
  s.runtime.observeStep(s.agent); assert.equal(s.runtime.states.get(s.agent).progress.current, 'accept');
  s.capture('新任务', 2); assert.equal(s.runtime.states.get(s.agent).acceptance, undefined);
});
test('missing acceptance tool leaves delivery explicitly unverified', async () => {
  const s = setup(); const result = await s.call('dispatch_accept');
  assert.equal(result.status, 'unverified');
  assert.equal(s.runtime.states.get(s.agent).progress.steps.find(s => s.id === 'accept').status, 'degraded');
});
test('subagent tasks are not captured or exposed as main tasks', async () => {
  const s = setup(); const child = { ...s.agent, id: 'child', session: { header: { parentSession: s.agent.id } } };
  s.runtime.capture({ agent: child, turn: 1, message: { source: { kind: 'user' }, content: [{ type: 'text', text: 'child task' }] } });
  await assert.rejects(s.call('dispatch_plan', { triage: 'L0' }, { ...s.exec, agent: child }), /No user-authored/);
});
test('host system messages contain prompt and model reports; route validates scope', async () => {
  const s = setup(); mount(s.ctx, s.settings);
  s.events.get('agent/inbox/claimed')({ agent: s.agent, turn: 1, message: { source: { kind: 'user' }, content: [{ type: 'text', text: '原始请求' }] } });
  await s.registered.find(t => t.name === 'dispatch_plan').execute({ triage: 'L1 证据' }, s.exec);
  const assembly = await s.events.get('system-prompt/assemble')({}, { agent: s.agent }, async () => ({ sections: [] }));
  assert.match(assembly.sections[0].text, /原始请求/); assert.match(assembly.sections[0].text, /L1 证据/);
  const route = s.routes.find(r => r.path.endsWith('/progress'));
  assert.equal((await route.fetch(new Request('http://test/progress', { method: 'POST', body: '{"sessionId":"missing"}' }))).status, 404);
  const response = await route.fetch(new Request('http://test/progress', { method: 'POST', body: '{"sessionId":"main-1"}' }));
  assert.equal((await response.json()).task.prompt, '原始请求');
});
test('containment nests owned skills and VENV; unrelated resources stay standalone', async () => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'orchestrator-catalog-'));
  try {
    const plugin = path.join(root, 'sample'); await fs.mkdir(path.join(plugin, 'skills', 's'), { recursive: true }); await fs.mkdir(path.join(plugin, '.venv'));
    await fs.writeFile(path.join(plugin, 'package.json'), JSON.stringify({ name: 'sample', dsh: { bundle: {} } }));
    await fs.writeFile(path.join(plugin, 'skills/s/SKILL.md'), 'test'); await fs.writeFile(path.join(plugin, '.venv/pyvenv.cfg'), 'home = test');
    const s = setup({ skills: [{ name: 'owned', description: '', path: path.join(plugin, 'skills/s/SKILL.md'), invocation: { modelInvocable: true } }, { name: 'standalone', description: '', invocation: { modelInvocable: true } }] });
    s.settings.assetRoots = [root];
    s.ctx.pluginManager.listBundles = async () => [{ name: 'sample', enabled: true, rows: [{ rowId: 'mcp-sample', entryId: 'include:mcp-sample', moduleName: 'mcp-client' }] }];
    s.ctx.pluginManager.listPlugins = async () => [{ entryId: 'include:mcp-sample', moduleName: 'mcp-client', enabled: true, fiberPhase: 'active' }];
    const catalog = await s.call('relic_prepare');
    assert.equal(catalog.skills.find(r => r.id === 'owned').ownerId, 'sample', JSON.stringify({ plugins: catalog.plugins, warnings: catalog.warnings })); assert.equal(catalog.skills.find(r => r.id === 'standalone').ownerId, undefined);
    assert.equal(catalog.plugins.find(r => r.id === 'sample').children.length, 3); assert.equal(catalog.environments[0].ownerId, 'sample');
  } finally { await fs.rm(root, { recursive: true }); }
});

test('five-layer catalog discovers public capabilities without calling foreign tools', async () => {
  const s = setup(); let calls = 0;
  s.ctx.tools.schemas = () => [
    { name: 'mcp__synabun__recall', description: 'Read conversation memory' },
    { name: 'memory_status', description: 'Read memory connection status' },
    { name: 'memory_remember', description: 'Write memory' },
    { name: 'fs_search', description: 'Search files' },
    { name: 'verifier_compare', description: 'Proposal check' },
    { name: 'subagent', description: 'Create a worker' },
  ];
  s.ctx.tools.execute = async () => { calls++; throw new Error('No automatic foreign call'); };
  s.ctx.pluginManager.listBundles = async () => [{ name: 'dsh-cosplay', enabled: true }, { name: 'dsh-agent-swarm', enabled: true }, { name: 'memory-connector', enabled: true }];
  const catalog = await s.call('relic_prepare');
  assert.ok(catalog.identity.some(row => row.id === 'dsh-cosplay'));
  assert.ok(catalog.organization.some(row => row.id === 'dsh-agent-swarm'));
  assert.ok(catalog.memory.some(row => row.kind === 'memory-database' && row.toolNames.includes('mcp__synabun__recall')));
  assert.equal(catalog.memory.some(row => row.toolNames?.includes('fs_search')), false);
  assert.equal(catalog.memory.some(row => row.id === 'memory_remember'), false);
  assert.deepEqual(catalog.verification.map(row => [row.name, row.status]), [['verifier_compare', 'available'], ['verifier_current_session', 'unavailable']]);
  assert.equal(catalog.memory.find(row => row.kind === 'memory-system').port, undefined);
  assert.equal(calls, 0);
});
test('memory transport reports are scoped, explicitly sourced and reset by steering', async () => {
  const s = setup();
  s.ctx.tools.schemas = () => [{ name: 'memory_status', description: 'Memory status' }];
  await s.call('relic_prepare');
  const result = await s.call('relic_record_observation', { layer: 'memory', resourceId: 'memory_status', summary: 'Observed running MCP HTTP endpoint', source: 'memory_status call abc', protocol: 'http', endpoint: 'http://127.0.0.1:8123/mcp' });
  assert.equal(result.port, 8123); assert.equal(result.verification, 'model-reported');
  await s.call('relic_record_observation', { layer: 'memory', resourceId: 'memory_status', summary: 'Actually stdio', source: 'memory_status call def', protocol: 'stdio' });
  assert.equal(s.runtime.states.get(s.agent).observations.length, 1); assert.equal(s.runtime.states.get(s.agent).observations[0].port, undefined);
  await assert.rejects(s.call('relic_record_observation', { layer: 'memory', resourceId: 'unknown', summary: 'No evidence', source: 'guess' }), /Unknown layer resource/);
  await assert.rejects(s.call('relic_record_observation', { layer: 'memory', resourceId: 'memory_status', summary: 'Bad URL', source: 'call', protocol: 'http', endpoint: 'http://user:password@127.0.0.1:1234/mcp' }), /without credentials/);
  await assert.rejects(s.call('relic_record_observation', { layer: 'memory', resourceId: 'memory_status', summary: 'Bad port', source: 'call', protocol: 'stdio', endpoint: 'http://127.0.0.1:1234' }), /no network endpoint/);
  s.capture('New constraints', 2); assert.equal(s.runtime.states.get(s.agent).observations, undefined);
});
test('registry arrays are not mutated and a private optional cwd service is never read', async () => {
  const s = setup(); const rows = Object.freeze([]);
  s.ctx.pluginManager.listPlugins = async () => rows;
  s.ctx.agentPresets.compositionInventory = async () => [{ id: 'dispatch-orchestrator', rows: [{ entryId: 'team', moduleName: 'agent-team', enabled: true, fiberPhase: 'active' }] }];
  Object.defineProperty(s.ctx, 'workingDirectory', { get() { throw new Error('Private service access'); } });
  const catalog = await s.call('relic_prepare');
  assert.ok(catalog.organization.some(row => row.id === 'agent-team')); assert.equal(rows.length, 0);
});
test('five layers enter real system sections and observations only appear in chosen scope', async () => {
  const s = setup(); s.ctx.tools.schemas = () => [{ name: 'memory_status', description: 'Memory status' }];
  mount(s.ctx, s.settings);
  s.events.get('agent/inbox/claimed')({ agent: s.agent, turn: 1, message: { source: { kind: 'user' }, content: [{ type: 'text', text: 'Task' }] } });
  const call = (name, args = {}) => s.registered.find(t => t.name === name).execute(args, s.exec);
  await call('relic_prepare'); await call('relic_record_observation', { layer: 'memory', resourceId: 'memory_status', summary: 'stdio running', source: 'public status result', protocol: 'stdio' });
  const assembly = await s.events.get('system-prompt/assemble')({}, { agent: s.agent }, async () => ({ sections: [] }));
  assert.match(assembly.sections[0].text, /verifier_compare/); assert.match(assembly.sections[0].text, /public status result/);
  const board = s.routes.find(row => row.path.endsWith('/board'));
  const scoped = await (await board.fetch(new Request('http://test/board', { method: 'POST', body: JSON.stringify({ sessionId: s.agent.id }) }))).json();
  const global = await (await board.fetch(new Request('http://test/board', { method: 'POST', body: '{}' }))).json();
  assert.ok(scoped.catalog.memory.some(row => row.kind === 'observation'));
  assert.equal(global.catalog.memory.some(row => row.kind === 'observation'), false);
});

test('each degraded stage keeps its own reason and a successful retry clears the old reason', async () => {
  const s = setup();
  s.ctx.skills.list = async () => { throw new Error('Skill registry offline'); };
  await s.call('relic_prepare');
  await s.call('dispatch_review', { triage: 'L1', comparison: 'Explicit unknown skill layer' });
  const state = s.runtime.states.get(s.agent);
  assert.match(state.progress.steps.find(step => step.id === 'compare').note, /Skill registry offline/);
  assert.match(state.progress.steps.find(step => step.id === 'verify').note, /verifier_compare is unavailable/);
  await s.call('dispatch_commit', { conclusion: 'Continue independent implementation' });
  assert.equal(state.progress.current, 'execute');
  assert.match(state.progress.steps.find(step => step.id === 'verify').note, /unavailable/);
  s.ctx.tools.get = () => ({});
  s.ctx.tools.execute = async () => ({ isError: false, value: { winner: 'A' }, content: [] });
  await s.call('dispatch_review', { triage: 'L1', comparison: 'Retry with the same public evidence' });
  assert.equal(state.progress.steps.find(step => step.id === 'verify').note, undefined);
  assert.equal(state.progress.steps.find(step => step.id === 'verify').status, 'done');
  assert.match(state.progress.steps.find(step => step.id === 'compare').note, /Skill registry offline/);
});
