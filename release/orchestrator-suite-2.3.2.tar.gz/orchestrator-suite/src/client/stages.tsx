/** One expandable row per observed stage; shared by compact status and board. */
import React, { useState } from 'react';
import { STAGES, type Stage, type TaskRecord } from '../shared';
export type StageTask = Omit<TaskRecord, 'catalog'>;
type Translate = (key: string) => string;
const fields = { input: 'prompt', triage: 'triage', compare: 'comparison', verify: 'review', assemble: 'conclusion', accept: 'acceptance' } as const;
function pretty(value: string): string {
  try { const parsed: unknown = JSON.parse(value); return typeof parsed === 'object' && parsed !== null ? JSON.stringify(parsed, null, 2) : value; } catch { return value; }
}
export function TaskStages({ task, t }: { task: StageTask; t: Translate }) {
  const [expanded, setExpanded] = useState<Partial<Record<Stage, boolean>>>({});
  return <ol className="os-stage-list" aria-label={t('progress.stages')}>{STAGES.map(id => {
    const step = task.progress.steps.find(step => step.id === id);
    if (!step) return null;
    const value = id === 'execute' ? '' : task[fields[id]];
    const issue = step.note || ((step.status === 'degraded' || step.status === 'failed') && task.progress.steps.filter(s => ['degraded', 'failed'].includes(s.status)).length === 1 ? task.progress.error : undefined);
    return <li key={id}><details className={`os-stage-row os-stage-${step.status}`} data-stage={id} open={!!expanded[id]} onToggle={event => {
      const open = event.currentTarget.open;
      setExpanded(previous => previous[id] === open ? previous : { ...previous, [id]: open });
    }} aria-current={id === task.progress.current ? 'step' : undefined}>
      <summary><span className="os-stage-chevron" aria-hidden="true">›</span><span className={`os-status-light os-status-${step.status}`} aria-hidden="true" /><strong>{t(`stage.${id}`)}</strong><span className="os-stage-state">{t(`progress.status.${step.status}`)}</span></summary>
      <div className="os-stage-evidence">
        {id === 'execute' ? <p>{step.startedAt ? t('progress.executionObserved') : t('progress.executionPending')}</p> : value ? <pre>{id === 'input' ? value : pretty(value)}</pre> : <p className="os-caption">{['degraded', 'failed', 'paused'].includes(step.status) ? t('progress.noResult') : step.status === 'skipped' ? t('progress.notCalled') : t('pending')}</p>}
        {issue && <div className="os-stage-issue"><strong>{t('progress.reason')}</strong><pre>{issue}</pre></div>}
        {(step.startedAt || step.finishedAt) && <dl className="os-stage-times">{step.startedAt && <><dt>{t('progress.started')}</dt><dd><time dateTime={step.startedAt}>{new Date(step.startedAt).toLocaleString()}</time></dd></>}{step.finishedAt && <><dt>{t('progress.finished')}</dt><dd><time dateTime={step.finishedAt}>{new Date(step.finishedAt).toLocaleString()}</time></dd></>}</dl>}
        {id === 'compare' && !!task.observations?.length && <details className="os-stage-observations"><summary>{t('task.observations')}</summary><pre>{JSON.stringify(task.observations, null, 2)}</pre></details>}
        {id === 'verify' && <p className="os-caption">{t('proposalEvidence')}</p>}
        {id === 'accept' && <p className="os-caption">{t('acceptanceEvidence')}</p>}
      </div>
    </details></li>;
  })}</ol>;
}
