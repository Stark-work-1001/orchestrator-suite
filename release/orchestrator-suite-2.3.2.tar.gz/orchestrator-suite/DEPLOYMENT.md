# 部署交付记录 / Deployment record

本文件描述**可复现的部署方法与验证边界**，不记录任何具体工作站上的目录、账户名或会话标识。
机器绑定的安装差异记录不随包分发；需要复现安装时按下文步骤执行并自行留存证据。

## 2.3.2 可移植性修订

本次迭代不改变运行时功能，只修正发布形态：

- `cordis.patch.yml` 的套件入口由本机绝对路径改为包名 `orchestrator-suite`，由宿主从
  profile 的 `node_modules` 解析。包因此可以安装到任意目录，无需改补丁。
- 随包 `suite.config.json` 的 `memoryRoots` 与 `assetRoots` 默认置空。部署方通过
  `ORCHESTRATOR_SUITE_CONFIG` 指向自己的配置文件来填写目录，**不需要修改包内文件**，
  升级也不会被覆盖。
- 新增 `scripts/privacy-scan.mjs` 并接入 `verify` 与 `pack`，作为发布门禁：命中本机绝对
  路径、UNC 路径、本地家目录、工具工作区目录、会话标识、邮箱、手机号、身份证号、
  非回环 IP 或凭据即中止打包。该脚本扫描自身源码，用于证明门禁不会被自身实现绕过。
- `scripts/preflight.mjs` 与 `scripts/install-symbolic.mjs` 取消内置本机默认路径，改为
  仅接受环境变量；证据报告写入前对路径与凭据做脱敏。
- 删除 `docs/installation.json` 与 `docs/plugin-audit.json`：二者是单台机器的部署差异与
  插件清单，对使用者没有价值，且会暴露本机资产构成。

## 安装

发布包解压到任意目录，然后通过 DSH 官方插件管理装配该目录。profile 以 `link:` +
SymbolicLink 指向解压目录，使源码改动即时生效。

**不要以 `file:目录` 或 tgz 方式复制安装**：那会得到一份拷贝而非链接，源码修改不会生效，
且失去与宿主版本的一致性。

`node scripts/install-symbolic.mjs` 仅用于本地开发目录与既有 profile 链接的对齐校验，
需要显式设置 `ORCHESTRATOR_PROFILE`；普通安装优先使用 `dsh plugin --profile <name> add <套件目录>`。
该脚本在替换链接前会校验目标与备份路径，拒绝覆盖既有链接；首次运行前请备份目标 profile。

## 需要真实宿主的检查

`node scripts/preflight.mjs` 读取一个真实 profile 的 `package.json`、`cordis.yml` 与
`cordis.patch.yml`，在套件自有的临时 `DSH_HOME` 中组合配置并要求 CLI 返回合并后的配置，
用来确认补丁结构合法且新入口确实进入组合结果。

- 需要 `ORCHESTRATOR_PROFILE`（profile 目录）与 `ORCHESTRATOR_DSH_CLI`（dsh 可执行文件）。
- 两者任一缺失或不可用时，脚本**如实记录 `status: "skipped"` 并以 0 退出**，不会伪造通过。
- 它只做配置组合：不应用补丁、不启动浏览器、不发起模型调用。
- 组合过程中报出的第三方插件告警会被记录但不由本套件修复；修改其他插件以迁就本套件不在范围内。

## 独立性与变更边界

部署只增加本套件的 profile 依赖、bundle 选择与本地链接，使用宿主公共接口注册。不修改
订阅/鉴权插件、验证器插件、其他插件或既有 agent preset 文件，也不重启整个宿主应用。

`node scripts/install-symbolic.mjs --baseline` 会记录当前 profile 与其他插件的源文件哈希，
用于事后核对本套件之外的文件是否被意外改动。该基线是**本机状态快照，属于机器绑定数据**，
不会被 `pack` 打进发布包。

## 验证结果与已知边界

发布流程内自动完成的：TypeScript 类型检查、生产构建、21 项自动回归、自包含依赖解析、
隐私扫描门禁，以及打包后逐文件哈希比对与解包复核。

**未**在发布流程内确认的，需要真实宿主与浏览器入口另行核验：

- 补丁应用后运行中是否真的生效（本流程不重启宿主）
- 真实裁判模型调用与评分结果
- 明暗主题下的看板与侧栏渲染
- 窄屏等移动端宽度

不得把"打包成功"或"自动测试通过"等同于以上任何一项已验证。
